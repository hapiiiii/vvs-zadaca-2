﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Tinder.ba;

namespace Unit_Testovi
{
    [TestClass]
    public class NoviTestovi
    {
        #region Data atributi
        static IEnumerable<object[]> Data
        {
            get
            {
                return new[]
                {
                    new object[] { "user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false},
                    new object[] {  "user2", "user2*+", Lokacija.Banja_Luka, Lokacija.Mostar, 45, false},
                    new object[] {  "user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 28, false}
                };
            }
        }

        static IEnumerable<object[]> WrongData
        {
            get
            {
                return new[]
                {
                    new object[] { "user1", "user1", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, true},
                    new object[] {  "user2", "", Lokacija.Banja_Luka, Lokacija.Mostar, 45, true},
                    new object[] {  "user3", "u", Lokacija.Sarajevo, Lokacija.Sarajevo, 28, false}
                };
            }
        }

        static IEnumerable<object[]> WrongData2
        {
            get
            {
                return new[]
                {
                    new object[] { "user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 17, false},
                    new object[] {  "user2", "user2*+", Lokacija.Banja_Luka, Lokacija.Mostar, 15, false},
                    new object[] {  "user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 10, false}
                };
            }
        }
        #endregion
        #region Zamjenski Objekti
        public class Stub : IRecenzija
        {
            public string DajUtisak()
            {
                return "Pozitivan";
            }
        }

        [TestMethod]
        public void TestZamjenskiObjekti(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Chat chat = new Chat(k1, k2);
            chat.Poruke.Add(new Poruka(k1, k2, "volim te, slobodan sam i slobodna si! hoću ljubav!"));
            IRecenzija r = new Stub();
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            bool uspješnost = t.DaLiJeSpajanjeUspjesno(chat, r);
            Assert.IsTrue(uspješnost);
        }

        #endregion
        #region Testovi za klasu Tinder

        [TestMethod]
        public void TestPotencijalChataVeliki()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);

            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "slobodna sam, volim i ja tebe!"));

            int potencijal = t.PotencijalChata(chat);

            Assert.AreEqual(potencijal, 60);
        }

        [TestMethod]
        public void TestPotencijalChataMali()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k3 = new Korisnik("user3", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);

            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "bježi, neću!"));
            int potencijal = t.PotencijalChata(chat);

            Assert.AreEqual(potencijal, 20);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestPotencijalChataIzuzetak()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);

            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, true);
            GrupniChat chat = (GrupniChat)t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "bježi, neću!"));

            int potencijal = t.PotencijalChata(chat);
        }

        //test ponasanje metode prilikom pokusaja dodavanja korisnika koji vec postoji
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void RadSaKorisnikomTinderIzuzetakKorisnikNePostoji(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.Korisnici.Add(k2);
            t.RadSaKorisnikom(k1, 0);
            t.RadSaKorisnikom(k2, 0);
        }

        //test ponasanja metode kada se proslijedi korisnik koji ne postoji u listi
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void RadSaKorisnikomTinderIzuzetakKorisnikPostoji(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.RadSaKorisnikom(k2, 1);

        }

        //test da li ce potencijal biti ispod nule
        [TestMethod]
        public void TestPotencijalChataIspodNule(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "udata sam!"));
            chat.Poruke.Add(new Poruka(k2, k1, "bježi, neću!"));
            int potencijal = t.PotencijalChata(chat);
            Assert.AreEqual(potencijal, 0);
        }

        //test da li ce potencijal biti iznad 100 
        [TestMethod]
        public void TestPotencijalChataIznadSto(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "volim i ja tebe, to mora da je ljubav!"));
            chat.Poruke.Add(new Poruka(k1, k2, "slobodan sam, jesi li ti slobodna?"));
            chat.Poruke.Add(new Poruka(k2, k1, "slobodna sam i hoću tebe"));
            int potencijal = t.PotencijalChata(chat);
            Assert.AreEqual(potencijal, 100);
        }

        //test da li ce korisnik biti dodat u listu
        [TestMethod]
        public void TestRadSaKorisnikomDodavanjeKorisnika(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.RadSaKorisnikom(k2, 0);
            Assert.AreEqual(t.Korisnici.Count, 2);
        }

        //test ponasanje metode ukoliko se obrise korisnik
        [TestMethod]
        public void RadSaKorisnikomTinderBrisanjeChata(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.Korisnici.Add(k2);
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "slobodan sam i volim te"));
            chat.Poruke.Add(new Poruka(k2, k1, "udata sam i bježi"));
            t.RadSaKorisnikom(k1, 1);
            Assert.AreEqual(t.Razgovori.Count, 0);
        }

        //test da li metoda vraca duplikate
        [TestMethod]
        public void TestZaTinderProvjeraDuplikata(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false, 24, 30);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Banja_Luka, 28, false, 19, 23);
            Korisnik k3 = new Korisnik("user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 35, false, 38, 40);
            Korisnik k4 = new Korisnik("user4", "user4*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 28, false, 19, 23);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.Korisnici.Add(k2);
            t.Korisnici.Add(k3);
            t.Korisnici.Add(k4);
            Assert.AreEqual(1, t.DajSveKompatibilneKorisnike().Count);
        }

        //test da li ce baciti izuzetak ukoliko posaljemo listu manju od 2 elementa
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void DodavanjeRazgovoraTinderIzuzetak(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.DodavanjeRazgovora(t.Korisnici, false);
        }

        //test da li metoda ispravno brise korisnika
        [TestMethod]
        public void RadSaKorisnikomTinderBrisanjeKorisnika(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.RadSaKorisnikom(k1, 1);
            Assert.AreEqual(t.Korisnici.Count, 0);
        }

        //test velicinu liste
        [TestMethod]
        public void TestZaTinder(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false, 24, 30);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 28, false, 19, 23);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.Korisnici.Add(k2);
            Assert.AreEqual(1, t.DajSveKompatibilneKorisnike().Count);
        }

        #endregion
        #region Testovi za klasu Chat

        //test da li je ispravan sadrzaj poruke
        [TestMethod]
        public void TestDajSvePorukeOdKorisnikaSadrzajPoruke()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k3 = new Korisnik("user3", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);

            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "bježi, necu!"));
            Assert.AreEqual("volim te!", chat.DajSvePorukeOdKorisnika(k1)[0].Sadrzaj);
            Assert.AreEqual("bježi, necu!", chat.DajSvePorukeOdKorisnika(k2)[0].Sadrzaj);
        }



        //test ispituje da li metoda baca izuzetak ako se datum pocetka chata postavi u buducnosti
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestZaDatumPocetakChataIzuzetak()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "volim i ja tebe, to mora da je ljubav!"));
            DateTime value = new DateTime(2021, 12, 31);
            chat.PocetakChata = value;
        }

        //test da li ce doci do izuzetka ukoliko se proslijedi datum za najnoviju poruku u buducnosti
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestZaDatumNajnovijaPorukaIzuzetak()
        {
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "bježi, to je neistina"));
            DateTime value = new DateTime(2021, 09, 03);
            chat.NajnovijaPoruka = value;
        }

        //test da li ce baciti izuzetak ukoliko se proslijedi korisnik koji nije posiljalac
        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestDajSvePorukeOdKorisnikaIzuzetak(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, true);
            GrupniChat chat = (GrupniChat)t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.DajSvePorukeOdKorisnika(k2);
        }

        //test velicinu liste ukoliko ima jedna poruka gdje je posiljalac k1
        [TestMethod]
        public void TestDajSvePorukeOdKorisnikaBrojPoruka(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "slobodan sam i volim te"));
            chat.Poruke.Add(new Poruka(k2, k1, "udata sam i bježi"));
            Assert.AreEqual(1, chat.DajSvePorukeOdKorisnika(k1).Count);
        }
        #endregion
        #region Testovi za klasu Poruka

        //test rada metode ukoliko se roslijedi vrijednost null za primaoca
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]

        public void TestImaLiPorukaPrimaoca()
        {
            Korisnik k1 = new Korisnik("user2", "user2*+", Lokacija.Mostar, Lokacija.Bihać, 23, false);
            Korisnik k2 = new Korisnik("user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 25, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, null, "bježi"));
        }

        //tset da li metoda baca izuzetak ukoliko proslijedimo vrijednost null za posiljaoca
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]

        public void TestImaLiPorukaPošiljaoca(){
            Korisnik k1 = new Korisnik("user2", "user2*+", Lokacija.Mostar, Lokacija.Bihać, 23, false);
            Korisnik k2 = new Korisnik("user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 25, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(null, k2, "volim te!"));
        }

        //test da li metoda baca izuzetak ako se proslijedi pogrsna rijec
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]

        public void TestSadrzajaPorukeIzuzetak()
        {
            Korisnik k1 = new Korisnik("user2", "user2*+", Lokacija.Mostar, Lokacija.Bihać, 23, false);
            Korisnik k2 = new Korisnik("user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 25, false);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.DodavanjeRazgovora(new List<Korisnik>() { k1, k2 }, false);
            Chat chat = t.Razgovori[0];
            chat.Poruke.Add(new Poruka(k1, k2, "volim te!"));
            chat.Poruke.Add(new Poruka(k2, k1, "pogrdna riječ"));
        }


        //test da li ce potencijal biti 0 koliko se posalju negativne rijeci
        [TestMethod]
        public void TestIPotencijalPoruke1(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Mostar, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Poruka poruka = new Poruka(k1, k2, "bježi,udata sam,to je neistina!");
            int potencijal = poruka.IzračunajPotencijalPoruke();
            Assert.AreEqual(0, potencijal);
        }
       

        //test potencijal ukoliko se posalju 2 pozitivne i jedna negativna rijec
        [TestMethod]
        public void TestPotencijalaPoruke2(){
            Korisnik k1 = new Korisnik("user1", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Korisnik k2 = new Korisnik("user2", "user2*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            Poruka poruka = new Poruka(k1, k2, "slobodna sam i volim te, ali ti si oženjen!");
            int potencijal = poruka.IzračunajPotencijalPoruke();
            Assert.AreEqual(20, potencijal);
        }


        #endregion
        #region Testovi za klasu Korisnik

        //test ispravnost imena
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravnoime(){ 
            Korisnik k = new Korisnik("", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
        }

        //test da li je korisnik razveden
        [TestMethod]
        public void TestDaLiJeRazveden(){
            Korisnik k1 = new Korisnik("user8", "user8*+", Lokacija.Sarajevo, Lokacija.Zenica, 39, false);
            k1.RazvediSe();
            Assert.IsTrue(k1.Razvod);

        }

        //test da li vraca ispravnu zeljenu lokaciju 
        [TestMethod]
        public void TestLokacijeRazvedenog(){
            Korisnik k = new Korisnik("user3", "user3*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 31, true);
            k.RazvediSe();
            Assert.AreNotEqual(Lokacija.Sarajevo, k.ZeljenaLokacija);
            Assert.AreEqual(Lokacija.Banja_Luka, k.ZeljenaLokacija);
        }

        //test funkcionalnost metode
        [TestMethod]
        public void TestRazvediSe()
        {
            Korisnik k = new Korisnik("user1", "user1*+", Lokacija.Trebinje, Lokacija.Trebinje, 25, false);
            k.RazvediSe();
            Assert.AreEqual(k.ZeljenaLokacija, Lokacija.Mostar);
            Assert.AreEqual(k.Razvod, true);
            Assert.AreEqual(k.ZeljeniMaxGodina, 29);
            Assert.AreEqual(k.ZeljeniMinGodina, 21);
        }

        //test ispravnost godina
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravneGodine()
        {
            Korisnik k = new Korisnik("Niko", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 16, false);
            int god = k.Godine;
        }

        //tset ispravnost max godina
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravneZeljeniMaxGodina()
        {
            Korisnik k = new Korisnik("Niko", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            k.ZeljeniMaxGodina = k.Godine - 6;
        }

        //test ispravnost passworda
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravanPassword(){
            Korisnik k = new Korisnik("Niko", "pass", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
        }

        //test ispravnost zeljenih max godina
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravneZeljeniMaxGodina1()
        {
            Korisnik k = new Korisnik("Niko", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            k.ZeljeniMaxGodina = k.Godine + 11;
        }

        //tset ispravnost zeljenih min godina
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravneZeljeniMinGodina(){
            Korisnik k = new Korisnik("Niko", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            k.ZeljeniMinGodina = k.Godine + 6;
        }

        //test ispravnost zeljenih min godina
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void TestKorisnikNeispravneZeljeniMinGodina1(){
            Korisnik k = new Korisnik("Niko", "user1*+", Lokacija.Sarajevo, Lokacija.Sarajevo, 20, false);
            k.ZeljeniMinGodina = k.Godine - 11;
        }
        #endregion
        #region Testovi za klasu Grupni chat

        //test bacanje izuzetka ukoliko se proslijedi prazan string
        [TestMethod]
        [ExpectedException(typeof(System.FormatException))]
        public void TestPosaljiPorukuViseKorisnika(){
            Korisnik k1 = new Korisnik();
            Korisnik k2 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k3 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            List<Korisnik> korisnici = new List<Korisnik>();
            korisnici.Add(k2);
            korisnici.Add(k3);
            GrupniChat g = new GrupniChat(korisnici);
            g.PosaljiPorukuViseKorisnika(k1, korisnici, "");
        }

        //test da li kontruktor pravi novu listu 
        [TestMethod]
        public void TestZaKonstruktor(){
            GrupniChat chat = new GrupniChat(null);
            Assert.AreEqual(chat.Korisnici.Count, 0);
        }

        //test listu poruka ukoliko metoda uspjesno izvrsi funkcionalnost
        [TestMethod]
        public void PosaljiPorukaViseKorisnikaTest(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user13", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Korisnik k3 = new Korisnik("user14", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            t.Korisnici.Add(k2);
            t.Korisnici.Add(k3);
            GrupniChat chat = new GrupniChat(t.Korisnici);
            chat.PosaljiPorukuViseKorisnika(k1, t.Korisnici, "Poruka koja se salje");
            Assert.AreEqual(chat.Poruke.Count, 3);
        }

        //test da li ce doci do izuzetka ukoliko se posalje lista ciji je broj elemenata manji od 2 
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void PosaljiPorukuViseKorisnikaIzuzetak(){
            Korisnik k1 = new Korisnik("user12", "user12*+", Lokacija.Bihać, Lokacija.Mostar, 23, false);
            Korisnik k2 = new Korisnik("user14", "user13*+", Lokacija.Zenica, Lokacija.Tuzla, 28, true);
            Tinder.ba.Tinder t = new Tinder.ba.Tinder();
            t.Korisnici.Add(k1);
            GrupniChat chat = new GrupniChat(t.Korisnici);
            chat.PosaljiPorukuViseKorisnika(k2, t.Korisnici, "Poruka koja se salje");
        }
        #endregion
        #region Testovi za klasu Recenzija

        //test bacanje izuzetka - metoda nije implementirana (nije implementirana zbog 2 zadatka)
        [TestMethod]
        [ExpectedException(typeof(NotImplementedException))]
        public void TestBacaLiRecenzijaIzuzetak(){
            Recenzija r = new Recenzija();
            r.DajUtisak();
        }
        #endregion
        #region Data Driven testovi

        //test ispravnost postavljanja proslijedjenog imena
        [TestMethod]
        [DynamicData("Data")]
        public void DataDrivenTestiranjeImena(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced){
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
            Assert.AreEqual(k.Ime, name);
        }

        //test ispravnost passworda 
        [TestMethod]
        [DynamicData("Data")]
        public void DataDrivenTestiranjePassworda(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced)
        {
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
            Assert.AreEqual(k.Password, pass);
        }

        //test da li ce doci do izuzetka ukoliko proslijedimo neispravan password
        [TestMethod]
        [DynamicData("WrongData")]
        [ExpectedException(typeof(System.FormatException))]
        public void DataDrivenTestiranjeIzuzetak(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced)
        {
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
        }

        //test ispravnost proslijedjene lokacije
        [TestMethod]
        [DynamicData("Data")]
        public void DataDrivenTestiranjeLokacija(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced){
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
            Assert.AreEqual(k.Lokacija, location);
        }

        //test ispravnost postavljanja proslijedjenog statusa razvoda
        [TestMethod]
        [DynamicData("Data")]
        public void DataDrivenTestiranjeRazvod(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced)
        {
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
            Assert.IsFalse(k.Razvod);
        }

        //test da li ce doci do izuzetka ukoliko proslijedimo pogresne godine korisnika
        [TestMethod]
        [DynamicData("WrongData2")]
        [ExpectedException(typeof(System.FormatException))]
        public void DataDrivenTestiranjeIzuzetakGodine(string name, string pass, Lokacija location, Lokacija desiredLoc, int age, bool divorced){
            Korisnik k = new Korisnik(name, pass, location, desiredLoc, age, divorced);
        }
        #endregion

    }

}

