﻿using System;

namespace Tinder.ba
{
    public class Poruka
    {
        #region Atributi

        Korisnik posiljalac, primalac;
        string sadrzaj;

        #endregion

        #region Properties

        public Korisnik Posiljalac
        {
            get => posiljalac;
        }
        public Korisnik Primalac
        {
            get => primalac;
        }
        public string Sadrzaj
        {
            get => sadrzaj;
            set
            {
                if (String.IsNullOrWhiteSpace(value) || value.Contains("pogrdna riječ"))
                    throw new InvalidOperationException("Neispravan sadržaj poruke!");

                sadrzaj = value;
            }
        }

        #endregion

        #region Konstruktor

        public Poruka(Korisnik sender, Korisnik receiver, string content)
        {
            if (sender == null || receiver == null)
                throw new ArgumentNullException("Nedefinisan pošiljalac/primalac!");

            posiljalac = sender;
            primalac = receiver;
            Sadrzaj = content;
        }

        #endregion

        #region Metode

        /// <summary>
        /// Metoda za izračunavanje potencijala poruke.
        /// Maksimalni potencijal je 100, a minimalni 0.
        /// Ukoliko poruka sadrži riječi "bježi", "neću", "oženjen", "udata" ili "neistina" potencijal se smanjuje za 20 po prisutnoj riječi.
        /// Ukoliko poruka sadrži riječi "volim", "ljubav", "slobodan", "slobodna" ili "hoću" potencijal se povećava za 20 po prisutnoj riječi.
        /// </summary>
        /// <returns></returns>

        public int IzračunajPotencijalPoruke(){
            int potencijal = 0;
            char[] separators = { ',', '.', '!', ':', ' ', ';' };
            string[] words = sadrzaj.Split(separators);
            for (int i = 0; i < words.Length; i++){
                if (words[i].Contains("volim") || words[i].Contains("ljubav") || words[i].Contains("slobodan") || words[i].Contains("slobodna") || words[i].Contains("hoću"))
                    if (potencijal < 100) potencijal += 20;
                if (words[i].Contains("bježi") || words[i].Contains("neću") || words[i].Contains("oženjen") || words[i].Contains("udata") || words[i].Contains("neistina"))
                    if (potencijal > 0) potencijal -= 20;
            }
            return potencijal;
        }
        #endregion
    }
}
