# Prateći Programski Kodovi za Laboratorijske Vježbe

U ovom repozitoriju nalaze se programski kodovi za laboratorijske vježbe na predmetu *Verifikacija i Validacija Softvera*.

Navigacija:

- branch **lv1** - Inspekcija Koda;
- branch **lv2** - Unit Testiranje;
- branch **lv3** - Data-Driven Unit Testiranje;
- branch **lv4** - Zamjenski Objekti;
- branch **lv5** - Metrike i Refaktoring;
- branch **lv6** - Code Tuning;
- branch **lv7** - White Box Testiranje.
